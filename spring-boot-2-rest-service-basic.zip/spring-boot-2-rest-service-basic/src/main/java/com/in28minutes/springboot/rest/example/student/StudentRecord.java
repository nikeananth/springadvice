package com.in28minutes.springboot.rest.example.student;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

import java.io.Serializable;


public class StudentRecord implements Serializable {


    private Student[] student;

    public StudentRecord() {
        super();
    }

    public StudentRecord(Student[] student) {
        super();
        this.student = student;
    }

    public Student[] getStudent() {
        return student;
    }

    public void setStudent(Student[] student) {
        this.student = student;
    }
}
