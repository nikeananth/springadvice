package com.in28minutes.springboot.rest.example.student;

import io.micrometer.common.util.StringUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Validator;

import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ValidatorService {
    private final Validator validator;
    public void validate(Object object) {
        BeanPropertyBindingResult result = new BeanPropertyBindingResult(object,
                object.getClass().getSimpleName());
        validator.validate(object, result);
        String msg = result.getAllErrors().stream().map(String::valueOf)
                .collect(Collectors.joining("\n"));
        if (StringUtils.isNotEmpty(msg)) {
            throw new IllegalStateException(msg);
        }
    }
}